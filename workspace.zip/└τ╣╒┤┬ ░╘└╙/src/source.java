import java.io.IOException;
import java.util.Scanner;

public class source {

	public static int size;
	
	public static void main(String[] args) throws IOException {
	
		Scanner sc= new Scanner(System.in);
		String input = sc.next();
		size = Integer.parseInt(input);
		
		System.out.println(count);
	}

}
